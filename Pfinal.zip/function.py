import os

#Haga uso de estas listas para completar el script.
listA = ["2,4,6,8,10","1,3,7,9,10"]
listB = ["1,2,3,4,5,6","1,2,3,4,5,6"]
listC = ["5,10,15,20,25,30","1,14,21,28,35"]
A3 = []
B3 = []
C3 = []
#Here Functions
def encontrarA():
 A1 = listA[0]
 A2 = listA[1]  
 #print(A1)  
 i=0
 j=0

 for i in range (len(A2)):
   for j in range (len(A1)):
    if len(A1) == len(A2):
     i += 1
     j += 1 
 A3.append(j)	
 print("::: LISTA A: ", A3)

def encontrarB():
 B1 = listB[0]
 B2 = listB[1]  
 #print(A1)  
 i=0
 j=0

 for i in range (len(B1)):
   for j in range (len(B2)):
    if len(B1) == len(B2):
	    i += 1
   j += 1
 B3.append(B2) 
 print("::: LISTA B: ", B3)


def encontrarC():
 C1 = listC[0]
 C2 = listC[1]  
 #print(A1)  
 i=0
 j=0

 for i in range (len(C1)):
	 for j in range (len(C2)):
		 if len(C1) == len(C2):
			 i += 1
			 j += 1
			 C3.append(C1)
 print("::: NINGUNO: ",C3)