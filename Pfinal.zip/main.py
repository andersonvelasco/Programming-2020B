import os
from function import *
#from encontrarB import *

os.system("clear")

encontrarA()
encontrarB()
encontrarC()
#Here Main program